package com.sop.chapter6.testserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
